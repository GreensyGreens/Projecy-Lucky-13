# Function 1
def internationalboxofficetocsv():
    # Import modules
    import psycopg2
    import pandas as pd
    import datetime

    # Establish connection to database
    con = psycopg2.connect(
        host = "localhost",
        database = "data_13",
        user = "postgres",
        password = "Natas123"
    )

    # Cursor
    cur = con.cursor()

    # It is bad practice but for the sake of learning
    cur.execute("SELECT SUM(international_box_office), genre FROM movie GROUP BY genre ORDER BY SUM DESC")

    # Query output
    rows = cur.fetchall()

    # Create list for genre
    genre = [i[1] for i in rows]

    # Create list for sum of international_box_office
    sum_international_box_office = [i[0] for i in rows]

    # Close the cursor very importante :)
    cur.close()

    # Closing the connection
    con.close()

    # Create pandas dataframe
    df = pd.DataFrame(
        {'Genre': genre,
        'Sum_international_box_office': sum_international_box_office}
    )

    # Write to csv 
    df.to_csv(f'Sum_international_box_office_{datetime.datetime.now().strftime("%Y_%m_%d_%H-%M-%S")}.csv')

    # Confirmation of correct execution
    return print('Status OK')

internationalboxofficetocsv()









