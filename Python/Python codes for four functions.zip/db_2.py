# Function 2
def productionbudgettocsv():
    # Import modules
    import psycopg2
    import pandas as pd
    import datetime

    # Establish connection to database
    con = psycopg2.connect(
        host = "localhost",
        database = "data_13",
        user = "postgres",
        password = "Natas123"
    )

    # Cursor
    cur = con.cursor()

    # Execute SQL commant
    cur.execute("SELECT SUM(production_budget), genre FROM movie GROUP BY genre  ORDER BY SUM DESC")

    # Query output
    rows = cur.fetchall()

    # Create list for genre
    genre = [i[1] for i in rows]

    # Create list for sum of international_box_office
    production_budget = [i[0] for i in rows]

    # Close the cursor very importante :)
    cur.close()

    # Closing the connection
    con.close()

    # Create pandas dataframe
    df = pd.DataFrame(
        {'Genre': genre,
        'Production_budget': production_budget}
    )

    # Write to csv 
    df.to_csv(f'sum_production_budget_{datetime.datetime.now().strftime("%Y_%m_%d_%H-%M-%S")}.csv')

    # Confirmation of correct execution
    return print('Status OK')

productionbudgettocsv()

