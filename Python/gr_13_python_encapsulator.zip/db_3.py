# Function 1
def boxoffice_vs_productionbudgettocsv():
    # Import modules
    import psycopg2
    import pandas as pd
    import datetime

    # Establish connection to database
    con = psycopg2.connect(
        host = "localhost",
        database = "data_13",
        user = "postgres",
        password = "Natas123"
    )

    # Cursor
    cur = con.cursor()

    # Execute SQL query
    cur.execute("SELECT worldwide_box_office, production_budget, title FROM movie WHERE production_budget >1 GROUP BY worldwide_box_office, production_budget, title ORDER BY production_budget DESC;")

    # Query output
    rows = cur.fetchall()

    # Create list for genre
    worldwide_box_office = [i[0] for i in rows]

    # Create list for production_budget
    production_budget = [i[1] for i in rows]

    # Create list for title
    title = [i[2] for i in rows]

    # Close the cursor
    cur.close()

    # Closing the connection
    con.close()

    # Create pandas dataframe
    df = pd.DataFrame(
        {'worldwide_box_office': worldwide_box_office,
        'production_budget': production_budget,
        'title': title}
    )

    # Write to csv 
    df.to_csv(f'boxoffice_vs_budget{datetime.datetime.now().strftime("%Y_%m_%d_%H-%M-%S")}.csv')

    # Confirmation of correct execution
    return print('Status OK')

boxoffice_vs_productionbudgettocsv()









