# Function 2
def productionbudgettocsv():
    # Import modules
    import psycopg2
    import pandas as pd
    import datetime

    # Establish connection to database
    con = psycopg2.connect(
        host = "localhost",
        database = "data_13",
        user = "postgres",
        password = "Natas123"
    )

    # Cursor for SQL
    cur = con.cursor()

    # Execute SQL commant
    cur.execute("SELECT SUM(production_budget), genre FROM movie WHERE yyear <= '2022-09-22' AND yyear > '2012-09-22' GROUP BY genre ORDER BY SUM DESC")

    # Query output
    rows = cur.fetchall()

    # Create list for genre
    genre = [i[1] for i in rows]

    # Create list for sum of production budget
    production_budget = [i[0] for i in rows]

    # Close the cursor 
    cur.close()

    # Closing the connection
    con.close()

    # Create pandas dataframe
    df = pd.DataFrame(
        {'Genre': genre,
        'Production_budget': production_budget}
    )

    # Write to csv 
    df.to_csv(f'sum_production_budget_{datetime.datetime.now().strftime("%Y_%m_%d_%H-%M-%S")}.csv')

    # Confirmation of correct execution
    return print('Status OK')

productionbudgettocsv()

