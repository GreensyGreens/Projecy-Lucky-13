# Function 5
def topfive_actorslist_adventuretocsv():
    # Import modules
    import psycopg2
    import pandas as pd
    import datetime

    # Establish connection to database
    con = psycopg2.connect(
        host = "localhost",
        database = "data_13",
        user = "postgres",
        password = "Natas123"
    )

    # Cursor
    cur = con.cursor()

    # Execute SQL query
    cur.execute("SELECT movie.worldwide_box_office, movie.genre, movie.title, actor.title FROM actor INNER JOIN movie ON actor.fname=movie.title WHERE genre='Adventure' AND worldwide_box_office > 1 ORDER BY worldwide_box_office DESC limit 5")
    
    # Query output
    rows = cur.fetchall()

    # Create list for fname (later called actors)
    worldwide_box_office = [i[0] for i in rows]

    # Create list for title
    genre = [i[1] for i in rows]

    # Create list for genre
    titlemovie = [i[2] for i in rows]

    # Create list for worldwide_box_office
    actors = [i[3] for i in rows]

    # Close the cursor
    cur.close()

    # Closing the connection
    con.close()

    # Create pandas dataframe
    df = pd.DataFrame(
        {'worldwide_box_office': worldwide_box_office,
        'genre': genre,
        'titlemovies': titlemovie,
        'actors': actors}
        )

    # Write to csv 
    df.to_csv(f'top3_adventureactors{datetime.datetime.now().strftime("%Y_%m_%d_%H-%M-%S")}.csv')

    # Confirmation of correct execution
    return print('Status OK')

topfive_actorslist_adventuretocsv()









