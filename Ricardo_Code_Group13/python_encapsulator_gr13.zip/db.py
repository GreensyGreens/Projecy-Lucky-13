# Function 1
def worldwideboxofficetocsv():
    # Import modules
    import psycopg2
    import pandas as pd
    import datetime

    # Establish connection to database
    con = psycopg2.connect(
        host = "localhost",
        database = "mdd2",
        user = "postgres",
        password = "."
    )

    # Cursor
    cur = con.cursor()

    # Execute SQL query
    cur.execute("SELECT SUM(worldwide_box_office), genre.fName FROM movie, genre WHERE yyear <= '2022-09-22' AND yyear > '2012-09-22'  GROUP BY genre.fName ORDER BY SUM DESC;")

    # Query output
    rows = cur.fetchall()

    # Create list for genre
    genre = [i[1] for i in rows]

    # Create list for sum of international_box_office
    sum_worldwide_boxoffice = [i[0] for i in rows]

    # Close the cursor 
    cur.close()

    # Closing the connection
    con.close()

    # Create pandas dataframe
    df = pd.DataFrame(
        {'Genre': genre,
        'Sum_worldwide_boxoffice': sum_worldwide_boxoffice}
    )

    # Write to csv 
    df.to_csv(f'Sum_worldwide_boxoffice_{datetime.datetime.now().strftime("%Y_%m_%d_%H-%M-%S")}.csv')

    # Confirmation of correct execution
    return print('Status OK')

worldwideboxofficetocsv()









